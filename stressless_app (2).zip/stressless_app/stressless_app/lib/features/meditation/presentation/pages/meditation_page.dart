import 'package:flutter/material.dart';
import 'dart:async';

class MeditationPage extends StatefulWidget {
  const MeditationPage({super.key});

  @override
  State<MeditationPage> createState() => _MeditationPageState();
}

class _MeditationPageState extends State<MeditationPage> {
  bool _isPlaying = false;
  int _duration = 10; // minutes
  int _remainingSeconds = 600; // 10 minutes in seconds
  Timer? _timer;

  final List<MeditationSession> _sessions = [
    MeditationSession(
      title: 'Ocean Waves',
      duration: 15,
      type: 'Nature',
      icon: Icons.water,
      color: const Color(0xFF4facfe),
    ),
    MeditationSession(
      title: 'Forest Rain',
      duration: 20,
      type: 'Nature',
      icon: Icons.forest,
      color: const Color(0xFF43e97b),
    ),
    MeditationSession(
      title: 'Body Scan',
      duration: 10,
      type: 'Guided',
      icon: Icons.self_improvement,
      color: const Color(0xFFfa709a),
    ),
    MeditationSession(
      title: 'Loving Kindness',
      duration: 12,
      type: 'Guided',
      icon: Icons.favorite,
      color: const Color(0xFFfee140),
    ),
  ];

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _togglePlayPause() {
    if (_isPlaying) {
      _pauseMeditation();
    } else {
      _startMeditation();
    }
  }

  void _startMeditation() {
    setState(() {
      _isPlaying = true;
      if (_remainingSeconds == 0) {
        _remainingSeconds = _duration * 60;
      }
    });

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_remainingSeconds > 0) {
          _remainingSeconds--;
        } else {
          _completeMeditation();
        }
      });
    });
  }

  void _pauseMeditation() {
    setState(() => _isPlaying = false);
    _timer?.cancel();
  }

  void _completeMeditation() {
    _timer?.cancel();
    setState(() {
      _isPlaying = false;
      _remainingSeconds = 0;
    });

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('🎉 Well Done!'),
        content: const Text(
          'You\'ve completed your meditation session. How do you feel?',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _resetMeditation();
            },
            child: const Text('Finish'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _resetMeditation();
              // Could add mood tracking here
            },
            child: const Text('Log Mood'),
          ),
        ],
      ),
    );
  }

  void _resetMeditation() {
    setState(() {
      _remainingSeconds = _duration * 60;
      _isPlaying = false;
    });
  }

  String _formatTime(int seconds) {
    int minutes = seconds ~/ 60;
    int secs = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final progress = 1 - (_remainingSeconds / (_duration * 60));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Meditation'),
      ),
      body: Column(
        children: [
          // Timer Display
          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 250,
                        height: 250,
                        child: CircularProgressIndicator(
                          value: progress,
                          strokeWidth: 8,
                          backgroundColor: Colors.grey[200],
                          valueColor: AlwaysStoppedAnimation<Color>(
                            theme.colorScheme.primary,
                          ),
                        ),
                      ),
                      Column(
                        children: [
                          Text(
                            _formatTime(_remainingSeconds),
                            style: theme.textTheme.displayLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'remaining',
                            style: theme.textTheme.bodyLarge?.copyWith(
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 48),
                  
                  // Controls
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        iconSize: 48,
                        onPressed: () {
                          if (_duration > 5) {
                            setState(() {
                              _duration -= 5;
                              if (!_isPlaying) {
                                _remainingSeconds = _duration * 60;
                              }
                            });
                          }
                        },
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      const SizedBox(width: 24),
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: theme.colorScheme.primary,
                          boxShadow: [
                            BoxShadow(
                              color: theme.colorScheme.primary.withOpacity(0.3),
                              blurRadius: 20,
                              spreadRadius: 5,
                            ),
                          ],
                        ),
                        child: IconButton(
                          iconSize: 40,
                          color: Colors.white,
                          onPressed: _togglePlayPause,
                          icon: Icon(
                            _isPlaying ? Icons.pause : Icons.play_arrow,
                          ),
                        ),
                      ),
                      const SizedBox(width: 24),
                      IconButton(
                        iconSize: 48,
                        onPressed: () {
                          if (_duration < 60) {
                            setState(() {
                              _duration += 5;
                              if (!_isPlaying) {
                                _remainingSeconds = _duration * 60;
                              }
                            });
                          }
                        },
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    '$_duration minutes',
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Meditation Sessions
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Guided Sessions',
                  style: theme.textTheme.headlineMedium,
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 120,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _sessions.length,
                    itemBuilder: (context, index) {
                      final session = _sessions[index];
                      return _buildSessionCard(session);
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSessionCard(MeditationSession session) {
    return Container(
      width: 160,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            session.color,
            session.color.withOpacity(0.7),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () {
            setState(() {
              _duration = session.duration;
              _remainingSeconds = session.duration * 60;
            });
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(
                  session.icon,
                  color: Colors.white,
                  size: 32,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      session.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${session.duration} min • ${session.type}',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class MeditationSession {
  final String title;
  final int duration;
  final String type;
  final IconData icon;
  final Color color;

  MeditationSession({
    required this.title,
    required this.duration,
    required this.type,
    required this.icon,
    required this.color,
  });
}