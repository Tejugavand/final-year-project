import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive/hive.dart';

class AuthProvider extends ChangeNotifier {
  bool _isAuthenticated = false;
  bool _isLoading = false;
  String? _userId;
  String? _userName;
  String? _userEmail;
  String? _errorMessage;

  bool get isAuthenticated => _isAuthenticated;
  bool get isLoading => _isLoading;
  String? get userId => _userId;
  String? get userName => _userName;
  String? get userEmail => _userEmail;
  String? get errorMessage => _errorMessage;

  AuthProvider() {
    _loadUserData();
  }

  // Load user data from local storage
  Future<void> _loadUserData() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      _isAuthenticated = prefs.getBool('isAuthenticated') ?? false;
      _userId = prefs.getString('userId');
      _userName = prefs.getString('userName');
      _userEmail = prefs.getString('userEmail');
    } catch (e) {
      _errorMessage = 'Failed to load user data: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Register new user
  Future<bool> register({
    required String name,
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Validate input
      if (name.isEmpty || email.isEmpty || password.isEmpty) {
        _errorMessage = 'All fields are required';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      if (!_isValidEmail(email)) {
        _errorMessage = 'Please enter a valid email';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      if (password.length < 6) {
        _errorMessage = 'Password must be at least 6 characters';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // TODO: Implement actual registration API call
      // For now, simulate registration with local storage
      await Future.delayed(const Duration(seconds: 2));

      final userId = DateTime.now().millisecondsSinceEpoch.toString();

      // Save user data
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isAuthenticated', true);
      await prefs.setString('userId', userId);
      await prefs.setString('userName', name);
      await prefs.setString('userEmail', email);
      await prefs.setString('userPassword', password); // In production, never store plain passwords!

      // Initialize user box in Hive
      final userBox = await Hive.openBox('user_$userId');
      await userBox.put('name', name);
      await userBox.put('email', email);
      await userBox.put('created_at', DateTime.now().toIso8601String());

      _isAuthenticated = true;
      _userId = userId;
      _userName = name;
      _userEmail = email;
      _isLoading = false;
      notifyListeners();

      return true;
    } catch (e) {
      _errorMessage = 'Registration failed: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Login user
  Future<bool> login({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // Validate input
      if (email.isEmpty || password.isEmpty) {
        _errorMessage = 'Email and password are required';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // TODO: Implement actual login API call
      // For now, check against local storage
      await Future.delayed(const Duration(seconds: 2));

      final prefs = await SharedPreferences.getInstance();
      final storedEmail = prefs.getString('userEmail');
      final storedPassword = prefs.getString('userPassword');

      if (storedEmail == email && storedPassword == password) {
        _isAuthenticated = true;
        _userId = prefs.getString('userId');
        _userName = prefs.getString('userName');
        _userEmail = email;

        await prefs.setBool('isAuthenticated', true);

        _isLoading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = 'Invalid email or password';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } catch (e) {
      _errorMessage = 'Login failed: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Logout user
  Future<void> logout() async {
    _isLoading = true;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('isAuthenticated', false);
      // Note: We keep user data for next login

      _isAuthenticated = false;
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Logout failed: $e';
      _isLoading = false;
      notifyListeners();
    }
  }

  // Update user profile
  Future<bool> updateProfile({
    String? name,
    String? email,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();

      if (name != null && name.isNotEmpty) {
        await prefs.setString('userName', name);
        _userName = name;

        // Update in Hive
        if (_userId != null) {
          final userBox = await Hive.openBox('user_$_userId');
          await userBox.put('name', name);
        }
      }

      if (email != null && email.isNotEmpty && _isValidEmail(email)) {
        await prefs.setString('userEmail', email);
        _userEmail = email;

        // Update in Hive
        if (_userId != null) {
          final userBox = await Hive.openBox('user_$_userId');
          await userBox.put('email', email);
        }
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Profile update failed: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Change password
  Future<bool> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      if (newPassword.length < 6) {
        _errorMessage = 'Password must be at least 6 characters';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      final prefs = await SharedPreferences.getInstance();
      final storedPassword = prefs.getString('userPassword');

      if (storedPassword != currentPassword) {
        _errorMessage = 'Current password is incorrect';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      await prefs.setString('userPassword', newPassword);

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Password change failed: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Reset password (email-based)
  Future<bool> resetPassword(String email) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      if (!_isValidEmail(email)) {
        _errorMessage = 'Please enter a valid email';
        _isLoading = false;
        notifyListeners();
        return false;
      }

      // TODO: Implement actual password reset API call
      await Future.delayed(const Duration(seconds: 2));

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'Password reset failed: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Delete account
  Future<bool> deleteAccount() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      if (_userId != null) {
        // Delete user box from Hive
        await Hive.deleteBoxFromDisk('user_$_userId');
      }

      // Clear all user data
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();

      _isAuthenticated = false;
      _userId = null;
      _userName = null;
      _userEmail = null;
      _isLoading = false;
      notifyListeners();

      return true;
    } catch (e) {
      _errorMessage = 'Account deletion failed: $e';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  // Helper method to validate email
  bool _isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  // Clear error message
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}