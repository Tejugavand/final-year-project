import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';

class StressProvider extends ChangeNotifier {
  // Mood tracking
  List<MoodEntry> _moodEntries = [];
  double _averageMood = 0.0;
  int _currentStreak = 0;

  // Breathing exercises
  int _totalBreathingSessions = 0;
  int _breathingMinutesThisWeek = 0;

  // Meditation
  int _totalMeditationMinutes = 0;
  int _meditationSessionsThisWeek = 0;

  // Journal
  int _totalJournalEntries = 0;

  // Analytics
  Map<String, int> _activityBreakdown = {
    'meditation': 0,
    'breathing': 0,
    'journaling': 0,
    'mood_tracking': 0,
  };

  // Getters
  List<MoodEntry> get moodEntries => _moodEntries;
  double get averageMood => _averageMood;
  int get currentStreak => _currentStreak;
  int get totalBreathingSessions => _totalBreathingSessions;
  int get breathingMinutesThisWeek => _breathingMinutesThisWeek;
  int get totalMeditationMinutes => _totalMeditationMinutes;
  int get meditationSessionsThisWeek => _meditationSessionsThisWeek;
  int get totalJournalEntries => _totalJournalEntries;
  Map<String, int> get activityBreakdown => _activityBreakdown;

  StressProvider() {
    _loadData();
  }

  // Load data from Hive
  Future<void> _loadData() async {
    try {
      final box = await Hive.openBox('stress_data');

      // Load mood entries
      final moodData = box.get('mood_entries', defaultValue: []);
      _moodEntries = (moodData as List)
          .map((e) => MoodEntry.fromMap(Map<String, dynamic>.from(e)))
          .toList();

      // Load statistics
      _totalBreathingSessions = box.get('total_breathing_sessions', defaultValue: 0);
      _breathingMinutesThisWeek = box.get('breathing_minutes_this_week', defaultValue: 0);
      _totalMeditationMinutes = box.get('total_meditation_minutes', defaultValue: 0);
      _meditationSessionsThisWeek = box.get('meditation_sessions_this_week', defaultValue: 0);
      _totalJournalEntries = box.get('total_journal_entries', defaultValue: 0);

      // Load activity breakdown
      final activityData = box.get('activity_breakdown', defaultValue: {});
      if (activityData is Map) {
        _activityBreakdown = Map<String, int>.from(activityData);
      }

      _calculateStats();
      notifyListeners();
    } catch (e) {
      debugPrint('Error loading stress data: $e');
    }
  }

  // Save data to Hive
  Future<void> _saveData() async {
    try {
      final box = await Hive.openBox('stress_data');

      // Save mood entries
      await box.put('mood_entries', _moodEntries.map((e) => e.toMap()).toList());

      // Save statistics
      await box.put('total_breathing_sessions', _totalBreathingSessions);
      await box.put('breathing_minutes_this_week', _breathingMinutesThisWeek);
      await box.put('total_meditation_minutes', _totalMeditationMinutes);
      await box.put('meditation_sessions_this_week', _meditationSessionsThisWeek);
      await box.put('total_journal_entries', _totalJournalEntries);

      // Save activity breakdown
      await box.put('activity_breakdown', _activityBreakdown);
    } catch (e) {
      debugPrint('Error saving stress data: $e');
    }
  }

  // Add mood entry
  Future<void> addMoodEntry({
    required int mood,
    required List<String> activities,
    String? notes,
  }) async {
    final entry = MoodEntry(
      mood: mood,
      activities: activities,
      notes: notes,
      timestamp: DateTime.now(),
    );

    _moodEntries.insert(0, entry);
    _activityBreakdown['mood_tracking'] = (_activityBreakdown['mood_tracking'] ?? 0) + 1;

    _calculateStats();
    await _saveData();
    notifyListeners();
  }

  // Add breathing session
  Future<void> addBreathingSession({
    required int duration, // in minutes
    required String technique,
    required int cycles,
  }) async {
    _totalBreathingSessions++;
    _breathingMinutesThisWeek += duration;
    _activityBreakdown['breathing'] = (_activityBreakdown['breathing'] ?? 0) + 1;

    await _saveData();
    notifyListeners();
  }

  // Add meditation session
  Future<void> addMeditationSession({
    required int duration, // in minutes
    required String type,
  }) async {
    _totalMeditationMinutes += duration;
    _meditationSessionsThisWeek++;
    _activityBreakdown['meditation'] = (_activityBreakdown['meditation'] ?? 0) + 1;

    await _saveData();
    notifyListeners();
  }

  // Add journal entry
  Future<void> addJournalEntry() async {
    _totalJournalEntries++;
    _activityBreakdown['journaling'] = (_activityBreakdown['journaling'] ?? 0) + 1;

    await _saveData();
    notifyListeners();
  }

  // Calculate statistics
  void _calculateStats() {
    if (_moodEntries.isEmpty) {
      _averageMood = 0.0;
      _currentStreak = 0;
      return;
    }

    // Calculate average mood
    double sum = 0;
    for (var entry in _moodEntries) {
      sum += entry.mood;
    }
    _averageMood = sum / _moodEntries.length;

    // Calculate streak
    _currentStreak = _calculateStreak();
  }

  // Calculate current streak
  int _calculateStreak() {
    if (_moodEntries.isEmpty) return 0;

    int streak = 1;
    DateTime lastDate = _moodEntries[0].timestamp;

    for (int i = 1; i < _moodEntries.length; i++) {
      final currentDate = _moodEntries[i].timestamp;
      final difference = lastDate.difference(currentDate).inDays;

      if (difference == 1) {
        streak++;
        lastDate = currentDate;
      } else {
        break;
      }
    }

    return streak;
  }

  // Get mood entries for a specific period
  List<MoodEntry> getMoodEntriesForPeriod({
    required DateTime start,
    required DateTime end,
  }) {
    return _moodEntries.where((entry) {
      return entry.timestamp.isAfter(start) && entry.timestamp.isBefore(end);
    }).toList();
  }

  // Get mood trend (last 7 days)
  List<double> getMoodTrend() {
    final now = DateTime.now();
    final trend = <double>[];

    for (int i = 6; i >= 0; i--) {
      final date = now.subtract(Duration(days: i));
      final entries = _moodEntries.where((entry) {
        return entry.timestamp.year == date.year &&
            entry.timestamp.month == date.month &&
            entry.timestamp.day == date.day;
      }).toList();

      if (entries.isEmpty) {
        trend.add(0);
      } else {
        double sum = 0;
        for (var entry in entries) {
          sum += entry.mood;
        }
        trend.add(sum / entries.length);
      }
    }

    return trend;
  }

  // Get insights
  List<String> getInsights() {
    final insights = <String>[];

    // Mood insights
    if (_averageMood >= 4) {
      insights.add('Your mood has been great this week! Keep it up! 🎉');
    } else if (_averageMood >= 3) {
      insights.add('Your mood is stable. Consider more self-care activities.');
    } else {
      insights.add('We noticed your mood could use a boost. Try meditation or journaling.');
    }

    // Streak insights
    if (_currentStreak >= 7) {
      insights.add('Amazing! You\'ve maintained a $-day streak! 🔥');
    } else if (_currentStreak >= 3) {
      insights.add('You\'re building a great habit with a $_currentStreak-day streak!');
    }

    // Activity insights
    if (_meditationSessionsThisWeek < 3) {
      insights.add('Try to meditate at least 3 times this week for better results.');
    }

    if (_breathingMinutesThisWeek > 30) {
      insights.add('Great breathing practice this week! You\'ve completed $_breathingMinutesThisWeek minutes.');
    }

    return insights;
  }

  // Reset weekly stats (call this at the start of each week)
  Future<void> resetWeeklyStats() async {
    _breathingMinutesThisWeek = 0;
    _meditationSessionsThisWeek = 0;
    await _saveData();
    notifyListeners();
  }

  // Clear all data
  Future<void> clearAllData() async {
    _moodEntries.clear();
    _totalBreathingSessions = 0;
    _breathingMinutesThisWeek = 0;
    _totalMeditationMinutes = 0;
    _meditationSessionsThisWeek = 0;
    _totalJournalEntries = 0;
    _activityBreakdown = {
      'meditation': 0,
      'breathing': 0,
      'journaling': 0,
      'mood_tracking': 0,
    };

    await _saveData();
    notifyListeners();
  }
}

// Mood Entry Model
class MoodEntry {
  final int mood; // 1-5
  final List<String> activities;
  final String? notes;
  final DateTime timestamp;

  MoodEntry({
    required this.mood,
    required this.activities,
    this.notes,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'mood': mood,
      'activities': activities,
      'notes': notes,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  factory MoodEntry.fromMap(Map<String, dynamic> map) {
    return MoodEntry(
      mood: map['mood'] ?? 3,
      activities: List<String>.from(map['activities'] ?? []),
      notes: map['notes'],
      timestamp: DateTime.parse(map['timestamp']),
    );
  }
}