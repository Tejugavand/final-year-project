import 'package:hive/hive.dart';
import 'api_service.dart';

class StressService {
  static const String _stressBoxName = 'stress_data';
  static const String _moodBoxName = 'mood_entries';
  static const String _breathingBoxName = 'breathing_sessions';
  static const String _meditationBoxName = 'meditation_sessions';
  static const String _journalBoxName = 'journal_entries';

  // ============ MOOD TRACKING ============

  // Save mood entry
  static Future<bool> saveMoodEntry({
    required int mood,
    required List<String> activities,
    String? notes,
  }) async {
    try {
      final box = await Hive.openBox(_moodBoxName);
      
      final entry = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'mood': mood,
        'activities': activities,
        'notes': notes,
        'timestamp': DateTime.now().toIso8601String(),
      };

      await box.add(entry);

      // Sync with API
      await _syncMoodToAPI(entry);

      return true;
    } catch (e) {
      return false;
    }
  }

  // Get mood entries
  static Future<List<Map<String, dynamic>>> getMoodEntries({
    DateTime? startDate,
    DateTime? endDate,
  }) async {
    try {
      final box = await Hive.openBox(_moodBoxName);
      final entries = box.values.map((e) => Map<String, dynamic>.from(e)).toList();

      if (startDate != null && endDate != null) {
        return entries.where((entry) {
          final timestamp = DateTime.parse(entry['timestamp']);
          return timestamp.isAfter(startDate) && timestamp.isBefore(endDate);
        }).toList();
      }

      return entries;
    } catch (e) {
      return [];
    }
  }

  // Get mood statistics
  static Future<MoodStatistics> getMoodStatistics() async {
    try {
      final entries = await getMoodEntries();
      
      if (entries.isEmpty) {
        return MoodStatistics(
          averageMood: 0,
          totalEntries: 0,
          currentStreak: 0,
          bestMoodDay: null,
          worstMoodDay: null,
        );
      }

      // Calculate average
      double sum = 0;
      for (var entry in entries) {
        sum += entry['mood'];
      }
      final averageMood = sum / entries.length;

      // Calculate streak
      int streak = _calculateStreak(entries);

      // Find best and worst mood days
      entries.sort((a, b) => b['mood'].compareTo(a['mood']));
      final bestMood = entries.first;
      final worstMood = entries.last;

      return MoodStatistics(
        averageMood: averageMood,
        totalEntries: entries.length,
        currentStreak: streak,
        bestMoodDay: DateTime.parse(bestMood['timestamp']),
        worstMoodDay: DateTime.parse(worstMood['timestamp']),
      );
    } catch (e) {
      return MoodStatistics(
        averageMood: 0,
        totalEntries: 0,
        currentStreak: 0,
        bestMoodDay: null,
        worstMoodDay: null,
      );
    }
  }

  // ============ BREATHING EXERCISES ============

  // Save breathing session
  static Future<bool> saveBreathingSession({
    required String technique,
    required int duration,
    required int cycles,
  }) async {
    try {
      final box = await Hive.openBox(_breathingBoxName);
      
      final session = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'technique': technique,
        'duration': duration,
        'cycles': cycles,
        'timestamp': DateTime.now().toIso8601String(),
      };

      await box.add(session);

      // Sync with API
      await _syncBreathingToAPI(session);

      return true;
    } catch (e) {
      return false;
    }
  }

  // Get breathing sessions
  static Future<List<Map<String, dynamic>>> getBreathingSessions() async {
    try {
      final box = await Hive.openBox(_breathingBoxName);
      return box.values.map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (e) {
      return [];
    }
  }

  // Get breathing statistics
  static Future<BreathingStatistics> getBreathingStatistics() async {
    try {
      final sessions = await getBreathingSessions();
      
      if (sessions.isEmpty) {
        return BreathingStatistics(
          totalSessions: 0,
          totalMinutes: 0,
          totalCycles: 0,
          favoriteTechnique: null,
        );
      }

      int totalMinutes = 0;
      int totalCycles = 0;
      Map<String, int> techniques = {};

      for (var session in sessions) {
        totalMinutes += session['duration'] as int;
        totalCycles += session['cycles'] as int;
        
        final technique = session['technique'] as String;
        techniques[technique] = (techniques[technique] ?? 0) + 1;
      }

      // Find favorite technique
      String? favoriteTechnique;
      int maxCount = 0;
      techniques.forEach((technique, count) {
        if (count > maxCount) {
          maxCount = count;
          favoriteTechnique = technique;
        }
      });

      return BreathingStatistics(
        totalSessions: sessions.length,
        totalMinutes: totalMinutes,
        totalCycles: totalCycles,
        favoriteTechnique: favoriteTechnique,
      );
    } catch (e) {
      return BreathingStatistics(
        totalSessions: 0,
        totalMinutes: 0,
        totalCycles: 0,
        favoriteTechnique: null,
      );
    }
  }

  // ============ MEDITATION ============

  // Save meditation session
  static Future<bool> saveMeditationSession({
    required String type,
    required int duration,
  }) async {
    try {
      final box = await Hive.openBox(_meditationBoxName);
      
      final session = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'type': type,
        'duration': duration,
        'timestamp': DateTime.now().toIso8601String(),
      };

      await box.add(session);

      // Sync with API
      await _syncMeditationToAPI(session);

      return true;
    } catch (e) {
      return false;
    }
  }

  // Get meditation sessions
  static Future<List<Map<String, dynamic>>> getMeditationSessions() async {
    try {
      final box = await Hive.openBox(_meditationBoxName);
      return box.values.map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (e) {
      return [];
    }
  }

  // Get meditation statistics
  static Future<MeditationStatistics> getMeditationStatistics() async {
    try {
      final sessions = await getMeditationSessions();
      
      if (sessions.isEmpty) {
        return MeditationStatistics(
          totalSessions: 0,
          totalMinutes: 0,
          averageSessionLength: 0,
          favoriteType: null,
        );
      }

      int totalMinutes = 0;
      Map<String, int> types = {};

      for (var session in sessions) {
        totalMinutes += session['duration'] as int;
        
        final type = session['type'] as String;
        types[type] = (types[type] ?? 0) + 1;
      }

      // Find favorite type
      String? favoriteType;
      int maxCount = 0;
      types.forEach((type, count) {
        if (count > maxCount) {
          maxCount = count;
          favoriteType = type;
        }
      });

      return MeditationStatistics(
        totalSessions: sessions.length,
        totalMinutes: totalMinutes,
        averageSessionLength: (totalMinutes / sessions.length).round(),
        favoriteType: favoriteType,
      );
    } catch (e) {
      return MeditationStatistics(
        totalSessions: 0,
        totalMinutes: 0,
        averageSessionLength: 0,
        favoriteType: null,
      );
    }
  }

  // ============ JOURNAL ============

  // Save journal entry
  static Future<bool> saveJournalEntry({
    required String title,
    required String content,
    required int mood,
  }) async {
    try {
      final box = await Hive.openBox(_journalBoxName);
      
      final entry = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'title': title,
        'content': content,
        'mood': mood,
        'timestamp': DateTime.now().toIso8601String(),
      };

      await box.add(entry);

      // Sync with API
      await _syncJournalToAPI(entry);

      return true;
    } catch (e) {
      return false;
    }
  }

  // Get journal entries
  static Future<List<Map<String, dynamic>>> getJournalEntries() async {
    try {
      final box = await Hive.openBox(_journalBoxName);
      return box.values.map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (e) {
      return [];
    }
  }

  // ============ ANALYTICS ============

  // Get overall statistics
  static Future<OverallStatistics> getOverallStatistics() async {
    final moodStats = await getMoodStatistics();
    final breathingStats = await getBreathingStatistics();
    final meditationStats = await getMeditationStatistics();
    final journalEntries = await getJournalEntries();

    return OverallStatistics(
      moodStats: moodStats,
      breathingStats: breathingStats,
      meditationStats: meditationStats,
      totalJournalEntries: journalEntries.length,
    );
  }

  // Get insights
  static Future<List<String>> getInsights() async {
    final insights = <String>[];
    final stats = await getOverallStatistics();

    // Mood insights
    if (stats.moodStats.averageMood >= 4) {
      insights.add('Your mood has been excellent! Keep up the great work! 🎉');
    } else if (stats.moodStats.averageMood < 3) {
      insights.add('We noticed your mood could use a boost. Try more self-care activities.');
    }

    // Streak insights
    if (stats.moodStats.currentStreak >= 7) {
      insights.add('Amazing! ${stats.moodStats.currentStreak}-day streak! 🔥');
    }

    // Meditation insights
    if (stats.meditationStats.totalMinutes >= 100) {
      insights.add('Wow! You\'ve meditated for ${stats.meditationStats.totalMinutes} minutes!');
    }

    // Breathing insights
    if (stats.breathingStats.totalSessions >= 20) {
      insights.add('Great breathing practice! ${stats.breathingStats.totalSessions} sessions completed!');
    }

    return insights;
  }

  // ============ SYNC WITH API ============

  static Future<void> _syncMoodToAPI(Map<String, dynamic> entry) async {
    try {
      await ApiService.post('/stress/mood', entry);
    } catch (e) {
      // Will sync later
    }
  }

  static Future<void> _syncBreathingToAPI(Map<String, dynamic> session) async {
    try {
      await ApiService.post('/stress/breathing', session);
    } catch (e) {
      // Will sync later
    }
  }

  static Future<void> _syncMeditationToAPI(Map<String, dynamic> session) async {
    try {
      await ApiService.post('/stress/meditation', session);
    } catch (e) {
      // Will sync later
    }
  }

  static Future<void> _syncJournalToAPI(Map<String, dynamic> entry) async {
    try {
      await ApiService.post('/stress/journal', entry);
    } catch (e) {
      // Will sync later
    }
  }

  // ============ HELPER METHODS ============

  static int _calculateStreak(List<Map<String, dynamic>> entries) {
    if (entries.isEmpty) return 0;

    entries.sort((a, b) {
      final dateA = DateTime.parse(a['timestamp']);
      final dateB = DateTime.parse(b['timestamp']);
      return dateB.compareTo(dateA);
    });

    int streak = 1;
    DateTime lastDate = DateTime.parse(entries[0]['timestamp']);

    for (int i = 1; i < entries.length; i++) {
      final currentDate = DateTime.parse(entries[i]['timestamp']);
      final difference = lastDate.difference(currentDate).inDays;

      if (difference == 1) {
        streak++;
        lastDate = currentDate;
      } else {
        break;
      }
    }

    return streak;
  }

  // Clear all data
  static Future<void> clearAllData() async {
    await Hive.deleteBoxFromDisk(_moodBoxName);
    await Hive.deleteBoxFromDisk(_breathingBoxName);
    await Hive.deleteBoxFromDisk(_meditationBoxName);
    await Hive.deleteBoxFromDisk(_journalBoxName);
  }
}

// ============ MODELS ============

class MoodStatistics {
  final double averageMood;
  final int totalEntries;
  final int currentStreak;
  final DateTime? bestMoodDay;
  final DateTime? worstMoodDay;

  MoodStatistics({
    required this.averageMood,
    required this.totalEntries,
    required this.currentStreak,
    this.bestMoodDay,
    this.worstMoodDay,
  });
}

class BreathingStatistics {
  final int totalSessions;
  final int totalMinutes;
  final int totalCycles;
  final String? favoriteTechnique;

  BreathingStatistics({
    required this.totalSessions,
    required this.totalMinutes,
    required this.totalCycles,
    this.favoriteTechnique,
  });
}

class MeditationStatistics {
  final int totalSessions;
  final int totalMinutes;
  final int averageSessionLength;
  final String? favoriteType;

  MeditationStatistics({
    required this.totalSessions,
    required this.totalMinutes,
    required this.averageSessionLength,
    this.favoriteType,
  });
}

class OverallStatistics {
  final MoodStatistics moodStats;
  final BreathingStatistics breathingStats;
  final MeditationStatistics meditationStats;
  final int totalJournalEntries;

  OverallStatistics({
    required this.moodStats,
    required this.breathingStats,
    required this.meditationStats,
    required this.totalJournalEntries,
  });
}