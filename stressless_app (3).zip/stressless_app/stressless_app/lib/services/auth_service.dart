import 'package:shared_preferences/shared_preferences.dart';
import 'package:hive/hive.dart';
import 'api_service.dart';

class AuthService {
  static const String _userBoxName = 'user_data';

  // Register user
  static Future<AuthResult> register({
    required String name,
    required String email,
    required String password,
  }) async {
    try {
      // Validate input
      if (name.isEmpty || email.isEmpty || password.isEmpty) {
        return AuthResult(
          success: false,
          message: 'All fields are required',
        );
      }

      if (!_isValidEmail(email)) {
        return AuthResult(
          success: false,
          message: 'Please enter a valid email',
        );
      }

      if (password.length < 6) {
        return AuthResult(
          success: false,
          message: 'Password must be at least 6 characters',
        );
      }

      // Call API
      final response = await ApiService.post('/auth/register', {
        'name': name,
        'email': email,
        'password': password,
      });

      if (response.success) {
        // Save user data
        await _saveUserData(response.data);
        
        if (response.data['token'] != null) {
          await ApiService.saveAuthToken(response.data['token']);
        }

        return AuthResult(
          success: true,
          message: 'Registration successful',
          userData: response.data,
        );
      } else {
        return AuthResult(
          success: false,
          message: response.message,
        );
      }
    } catch (e) {
      return AuthResult(
        success: false,
        message: 'Registration failed: $e',
      );
    }
  }

  // Login user
  static Future<AuthResult> login({
    required String email,
    required String password,
  }) async {
    try {
      // Validate input
      if (email.isEmpty || password.isEmpty) {
        return AuthResult(
          success: false,
          message: 'Email and password are required',
        );
      }

      // Call API
      final response = await ApiService.post('/auth/login', {
        'email': email,
        'password': password,
      });

      if (response.success) {
        // Save user data
        await _saveUserData(response.data);
        
        if (response.data['token'] != null) {
          await ApiService.saveAuthToken(response.data['token']);
        }

        return AuthResult(
          success: true,
          message: 'Login successful',
          userData: response.data,
        );
      } else {
        return AuthResult(
          success: false,
          message: response.message,
        );
      }
    } catch (e) {
      return AuthResult(
        success: false,
        message: 'Login failed: $e',
      );
    }
  }

  // Logout user
  static Future<void> logout() async {
    try {
      // Call API to invalidate token (optional)
      await ApiService.post('/auth/logout', {});
    } catch (e) {
      // Continue with local logout even if API call fails
    }

    // Clear local data
    await ApiService.clearAuthToken();
    await _clearUserData();
  }

  // Get current user
  static Future<Map<String, dynamic>?> getCurrentUser() async {
    try {
      final box = await Hive.openBox(_userBoxName);
      final userData = box.get('current_user');
      
      if (userData != null) {
        return Map<String, dynamic>.from(userData);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // Update user profile
  static Future<AuthResult> updateProfile({
    String? name,
    String? email,
    String? phoneNumber,
  }) async {
    try {
      final body = <String, dynamic>{};
      if (name != null) body['name'] = name;
      if (email != null) body['email'] = email;
      if (phoneNumber != null) body['phone_number'] = phoneNumber;

      final response = await ApiService.put('/auth/profile', body);

      if (response.success) {
        await _saveUserData(response.data);
        
        return AuthResult(
          success: true,
          message: 'Profile updated successfully',
          userData: response.data,
        );
      } else {
        return AuthResult(
          success: false,
          message: response.message,
        );
      }
    } catch (e) {
      return AuthResult(
        success: false,
        message: 'Profile update failed: $e',
      );
    }
  }

  // Change password
  static Future<AuthResult> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      if (newPassword.length < 6) {
        return AuthResult(
          success: false,
          message: 'Password must be at least 6 characters',
        );
      }

      final response = await ApiService.post('/auth/change-password', {
        'current_password': currentPassword,
        'new_password': newPassword,
      });

      return AuthResult(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return AuthResult(
        success: false,
        message: 'Password change failed: $e',
      );
    }
  }

  // Reset password
  static Future<AuthResult> resetPassword(String email) async {
    try {
      if (!_isValidEmail(email)) {
        return AuthResult(
          success: false,
          message: 'Please enter a valid email',
        );
      }

      final response = await ApiService.post('/auth/reset-password', {
        'email': email,
      });

      return AuthResult(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return AuthResult(
        success: false,
        message: 'Password reset failed: $e',
      );
    }
  }

  // Verify email
  static Future<AuthResult> verifyEmail(String code) async {
    try {
      final response = await ApiService.post('/auth/verify-email', {
        'code': code,
      });

      if (response.success) {
        await _saveUserData(response.data);
      }

      return AuthResult(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return AuthResult(
        success: false,
        message: 'Email verification failed: $e',
      );
    }
  }

  // Delete account
  static Future<AuthResult> deleteAccount() async {
    try {
      final response = await ApiService.delete('/auth/account');

      if (response.success) {
        await logout();
      }

      return AuthResult(
        success: response.success,
        message: response.message,
      );
    } catch (e) {
      return AuthResult(
        success: false,
        message: 'Account deletion failed: $e',
      );
    }
  }

  // Check if user is logged in
  static Future<bool> isLoggedIn() async {
    return await ApiService.isAuthenticated();
  }

  // Save user data locally
  static Future<void> _saveUserData(dynamic data) async {
    try {
      final box = await Hive.openBox(_userBoxName);
      await box.put('current_user', data);

      // Also save to SharedPreferences for quick access
      final prefs = await SharedPreferences.getInstance();
      if (data['id'] != null) await prefs.setString('user_id', data['id'].toString());
      if (data['name'] != null) await prefs.setString('user_name', data['name']);
      if (data['email'] != null) await prefs.setString('user_email', data['email']);
    } catch (e) {
      // Handle error
    }
  }

  // Clear user data
  static Future<void> _clearUserData() async {
    try {
      final box = await Hive.openBox(_userBoxName);
      await box.clear();

      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('user_id');
      await prefs.remove('user_name');
      await prefs.remove('user_email');
    } catch (e) {
      // Handle error
    }
  }

  // Validate email
  static bool _isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  // Refresh auth token
  static Future<AuthResult> refreshToken() async {
    try {
      final response = await ApiService.post('/auth/refresh', {});

      if (response.success && response.data['token'] != null) {
        await ApiService.saveAuthToken(response.data['token']);
        return AuthResult(
          success: true,
          message: 'Token refreshed',
        );
      } else {
        return AuthResult(
          success: false,
          message: 'Failed to refresh token',
        );
      }
    } catch (e) {
      return AuthResult(
        success: false,
        message: 'Token refresh failed: $e',
      );
    }
  }
}

// Auth Result model
class AuthResult {
  final bool success;
  final String message;
  final Map<String, dynamic>? userData;

  AuthResult({
    required this.success,
    required this.message,
    this.userData,
  });

  @override
  String toString() {
    return 'AuthResult(success: $success, message: $message)';
  }
}