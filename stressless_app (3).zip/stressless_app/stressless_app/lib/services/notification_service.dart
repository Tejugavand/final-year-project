import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import 'package:shared_preferences/shared_preferences.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static bool _initialized = false;

  // Initialize notification service
  static Future<void> initialize() async {
    if (_initialized) return;

    // Initialize timezone
    tz.initializeTimeZones();

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    // Request permissions for iOS
    await _notifications
        .resolvePlatformSpecificImplementation
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );

    _initialized = true;
  }

  // Handle notification tap
  static void _onNotificationTapped(NotificationResponse response) {
    // Handle notification tap
    // You can navigate to specific screens based on payload
    final payload = response.payload;
    if (payload != null) {
      // Parse payload and navigate
      // Example: Navigator.push(...)
    }
  }

  // Show instant notification
  static Future<void> showInstantNotification({
    required String title,
    required String body,
    String? payload,
    int? id,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'stressless_instant',
      'Instant Notifications',
      channelDescription: 'Instant notifications for immediate updates',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails();

    const notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.show(
      id ?? DateTime.now().millisecond,
      title,
      body,
      notificationDetails,
      payload: payload,
    );
  }

  // Schedule daily reminder
  static Future<void> scheduleDailyReminder({
    required int id,
    required int hour,
    required int minute,
    required String title,
    required String body,
    String? payload,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'stressless_daily',
      'Daily Reminders',
      channelDescription: 'Daily wellness reminders',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails();

    const notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.zonedSchedule(
      id,
      title,
      body,
      _nextInstanceOfTime(hour, minute),
      notificationDetails,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
      payload: payload,
    );
  }

  // Calculate next instance of time
  static tz.TZDateTime _nextInstanceOfTime(int hour, int minute) {
    final now = tz.TZDateTime.now(tz.local);
    var scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hour,
      minute,
    );

    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    return scheduledDate;
  }

  // Schedule weekly reminder
  static Future<void> scheduleWeeklyReminder({
    required int id,
    required int weekday, // 1 = Monday, 7 = Sunday
    required int hour,
    required int minute,
    required String title,
    required String body,
    String? payload,
  }) async {
    const androidDetails = AndroidNotificationDetails(
      'stressless_weekly',
      'Weekly Reminders',
      channelDescription: 'Weekly wellness reminders',
      importance: Importance.high,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const iosDetails = DarwinNotificationDetails();

    const notificationDetails = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );

    await _notifications.zonedSchedule(
      id,
      title,
      body,
      _nextInstanceOfWeekday(weekday, hour, minute),
      notificationDetails,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
      payload: payload,
    );
  }

  // Calculate next instance of weekday
  static tz.TZDateTime _nextInstanceOfWeekday(int weekday, int hour, int minute) {
    var scheduledDate = _nextInstanceOfTime(hour, minute);
    
    while (scheduledDate.weekday != weekday) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }

    return scheduledDate;
  }

  // Cancel specific notification
  static Future<void> cancelNotification(int id) async {
    await _notifications.cancel(id);
  }

  // Cancel all notifications
  static Future<void> cancelAllNotifications() async {
    await _notifications.cancelAll();
  }

  // Get pending notifications
  static Future<List<PendingNotificationRequest>> getPendingNotifications() async {
    return await _notifications.pendingNotificationRequests();
  }

  // Preset notification IDs
  static const int morningReminderId = 1;
  static const int afternoonReminderId = 2;
  static const int eveningReminderId = 3;
  static const int bedtimeReminderId = 4;

  // Schedule morning reminder
  static Future<void> scheduleMorningReminder() async {
    await scheduleDailyReminder(
      id: morningReminderId,
      hour: 9,
      minute: 0,
      title: 'Good Morning! 🌅',
      body: 'Start your day with a 5-minute breathing exercise',
      payload: 'breathing',
    );

    // Save preference
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('morning_reminder_enabled', true);
  }

  // Schedule afternoon reminder
  static Future<void> scheduleAfternoonReminder() async {
    await scheduleDailyReminder(
      id: afternoonReminderId,
      hour: 14,
      minute: 0,
      title: 'Afternoon Check-in 🧘',
      body: 'How are you feeling? Take a mindful break',
      payload: 'mood',
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('afternoon_reminder_enabled', true);
  }

  // Schedule evening reminder
  static Future<void> scheduleEveningReminder() async {
    await scheduleDailyReminder(
      id: eveningReminderId,
      hour: 20,
      minute: 0,
      title: 'Wind Down 🌙',
      body: 'Take a moment to reflect on your day and log your mood',
      payload: 'journal',
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('evening_reminder_enabled', true);
  }

  // Schedule bedtime reminder
  static Future<void> scheduleBedtimeReminder() async {
    await scheduleDailyReminder(
      id: bedtimeReminderId,
      hour: 22,
      minute: 0,
      title: 'Time for Bed 😴',
      body: 'Try a 10-minute meditation for better sleep',
      payload: 'meditation',
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('bedtime_reminder_enabled', true);
  }

  // Cancel morning reminder
  static Future<void> cancelMorningReminder() async {
    await cancelNotification(morningReminderId);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('morning_reminder_enabled', false);
  }

  // Cancel afternoon reminder
  static Future<void> cancelAfternoonReminder() async {
    await cancelNotification(afternoonReminderId);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('afternoon_reminder_enabled', false);
  }

  // Cancel evening reminder
  static Future<void> cancelEveningReminder() async {
    await cancelNotification(eveningReminderId);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('evening_reminder_enabled', false);
  }

  // Cancel bedtime reminder
  static Future<void> cancelBedtimeReminder() async {
    await cancelNotification(bedtimeReminderId);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('bedtime_reminder_enabled', false);
  }

  // Check if reminder is enabled
  static Future<bool> isReminderEnabled(String reminderType) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('${reminderType}_reminder_enabled') ?? false;
  }

  // Show achievement notification
  static Future<void> showAchievementNotification({
    required String achievement,
    required String description,
  }) async {
    await showInstantNotification(
      title: '🎉 Achievement Unlocked!',
      body: '$achievement - $description',
      payload: 'achievement',
    );
  }

  // Show streak notification
  static Future<void> showStreakNotification(int streakDays) async {
    await showInstantNotification(
      title: '🔥 $streakDays Day Streak!',
      body: 'You\'re on fire! Keep up the great work!',
      payload: 'streak',
    );
  }

  // Show mood reminder
  static Future<void> showMoodReminder() async {
    await showInstantNotification(
      title: 'Don\'t forget! 📝',
      body: 'You haven\'t logged your mood today',
      payload: 'mood',
    );
  }
}