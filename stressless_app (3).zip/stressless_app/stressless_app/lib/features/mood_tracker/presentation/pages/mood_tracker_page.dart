import 'package:flutter/material.dart';
import 'package:stressless_app/core/theme/app_theme.dart';

class MoodTrackerPage extends StatefulWidget {
  const MoodTrackerPage({super.key});

  @override
  State<MoodTrackerPage> createState() => _MoodTrackerPageState();
}

class _MoodTrackerPageState extends State<MoodTrackerPage> {
  int? _selectedMood;
  final TextEditingController _notesController = TextEditingController();
  final List<String> _selectedActivities = [];

  final List<MoodOption> _moodOptions = [
    MoodOption(emoji: '😊', label: 'Excellent', value: 5, color: AppTheme.moodExcellent),
    MoodOption(emoji: '🙂', label: 'Good', value: 4, color: AppTheme.moodGood),
    MoodOption(emoji: '😐', label: 'Okay', value: 3, color: AppTheme.moodOkay),
    MoodOption(emoji: '😔', label: 'Bad', value: 2, color: AppTheme.moodBad),
    MoodOption(emoji: '😢', label: 'Terrible', value: 1, color: AppTheme.moodTerrible),
  ];

  final List<String> _activities = [
    'Work', 'Exercise', 'Sleep', 'Social', 'Family',
    'Hobbies', 'Nature', 'Reading', 'Music', 'Meditation'
  ];

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  void _saveMoodEntry() {
    if (_selectedMood == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a mood')),
      );
      return;
    }

    // TODO: Save to database
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Mood saved successfully! ✨'),
        backgroundColor: AppTheme.moodExcellent,
      ),
    );

    // Reset form
    setState(() {
      _selectedMood = null;
      _selectedActivities.clear();
      _notesController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Track Your Mood'),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () {
              // Show mood history
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Question
            Text(
              'How are you feeling right now?',
              style: theme.textTheme.displaySmall,
            ),
            const SizedBox(height: 24),

            // Mood Selector
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: _moodOptions.map((mood) {
                final isSelected = _selectedMood == mood.value;
                return GestureDetector(
                  onTap: () => setState(() => _selectedMood = mood.value),
                  child: Column(
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        width: isSelected ? 70 : 60,
                        height: isSelected ? 70 : 60,
                        decoration: BoxDecoration(
                          color: isSelected ? mood.color : Colors.grey[200],
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: isSelected
                              ? [
                                  BoxShadow(
                                    color: mood.color.withOpacity(0.3),
                                    blurRadius: 10,
                                    spreadRadius: 2,
                                  ),
                                ]
                              : null,
                        ),
                        child: Center(
                          child: Text(
                            mood.emoji,
                            style: TextStyle(fontSize: isSelected ? 36 : 28),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        mood.label,
                        style: theme.textTheme.bodySmall?.copyWith(
                          fontWeight:
                              isSelected ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 32),

            // Activities
            Text(
              'What influenced your mood?',
              style: theme.textTheme.headlineMedium,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _activities.map((activity) {
                final isSelected = _selectedActivities.contains(activity);
                return FilterChip(
                  label: Text(activity),
                  selected: isSelected,
                  onSelected: (selected) {
                    setState(() {
                      if (selected) {
                        _selectedActivities.add(activity);
                      } else {
                        _selectedActivities.remove(activity);
                      }
                    });
                  },
                  selectedColor: theme.colorScheme.primary.withOpacity(0.2),
                  checkmarkColor: theme.colorScheme.primary,
                );
              }).toList(),
            ),
            const SizedBox(height: 32),

            // Notes
            Text(
              'Add a note (optional)',
              style: theme.textTheme.headlineMedium,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _notesController,
              maxLines: 5,
              decoration: const InputDecoration(
                hintText: 'What\'s on your mind?',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 32),

            // Save Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveMoodEntry,
                style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text('Save Mood Entry'),
              ),
            ),
            const SizedBox(height: 16),

            // Quick Stats Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      'This Week',
                      style: theme.textTheme.titleMedium,
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildWeekStat('Entries', '5'),
                        _buildWeekStat('Avg Mood', '😊'),
                        _buildWeekStat('Streak', '3 days'),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeekStat(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey,
              ),
        ),
      ],
    );
  }
}

class MoodOption {
  final String emoji;
  final String label;
  final int value;
  final Color color;

  MoodOption({
    required this.emoji,
    required this.label,
    required this.value,
    required this.color,
  });
}