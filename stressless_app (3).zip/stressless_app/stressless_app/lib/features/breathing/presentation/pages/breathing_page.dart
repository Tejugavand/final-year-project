import 'dart:async';
import 'package:flutter/material.dart';

class BreathingPage extends StatefulWidget {
  const BreathingPage({super.key});

  @override
  State<BreathingPage> createState() => _BreathingPageState();
}

class _BreathingPageState extends State<BreathingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  String _breathingPhase = 'Tap to start';
  bool _isBreathing = false;
  int _breathCount = 0;
  Timer? _breathingTimer;

  final List<BreathingTechnique> _techniques = [
    BreathingTechnique(
      name: 'Box Breathing',
      description: 'Equal time for inhale, hold, exhale, hold',
      inhale: 4,
      holdAfterInhale: 4,
      exhale: 4,
      holdAfterExhale: 4,
      cycles: 5,
    ),
    BreathingTechnique(
      name: '4-7-8 Technique',
      description: 'Relaxation breathing for better sleep',
      inhale: 4,
      holdAfterInhale: 7,
      exhale: 8,
      holdAfterExhale: 0,
      cycles: 4,
    ),
    BreathingTechnique(
      name: 'Calm Breathing',
      description: 'Simple and effective for instant calm',
      inhale: 4,
      holdAfterInhale: 0,
      exhale: 6,
      holdAfterExhale: 0,
      cycles: 6,
    ),
    BreathingTechnique(
      name: 'Energizing Breath',
      description: 'Quick breathing to boost energy',
      inhale: 2,
      holdAfterInhale: 0,
      exhale: 2,
      holdAfterExhale: 0,
      cycles: 10,
    ),
  ];

  int _selectedTechniqueIndex = 0;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );

    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.5).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    _breathingTimer?.cancel();
    super.dispose();
  }

  void _startBreathing() {
    if (_isBreathing) {
      _stopBreathing();
      return;
    }

    setState(() {
      _isBreathing = true;
      _breathCount = 0;
    });

    _performBreathingCycle();
  }

  void _stopBreathing() {
    setState(() {
      _isBreathing = false;
      _breathingPhase = 'Tap to start';
    });
    _animationController.stop();
    _animationController.reset();
    _breathingTimer?.cancel();
  }

  void _performBreathingCycle() async {
    final technique = _techniques[_selectedTechniqueIndex];
    
    for (int cycle = 0; cycle < technique.cycles; cycle++) {
      if (!_isBreathing) break;

      // Inhale
      setState(() => _breathingPhase = 'Breathe in...');
      _animationController.duration = Duration(seconds: technique.inhale);
      await _animationController.forward();
      await Future.delayed(const Duration(milliseconds: 100));

      if (!_isBreathing) break;

      // Hold after inhale
      if (technique.holdAfterInhale > 0) {
        setState(() => _breathingPhase = 'Hold...');
        await Future.delayed(Duration(seconds: technique.holdAfterInhale));
      }

      if (!_isBreathing) break;

      // Exhale
      setState(() => _breathingPhase = 'Breathe out...');
      _animationController.duration = Duration(seconds: technique.exhale);
      await _animationController.reverse();
      await Future.delayed(const Duration(milliseconds: 100));

      if (!_isBreathing) break;

      // Hold after exhale
      if (technique.holdAfterExhale > 0) {
        setState(() => _breathingPhase = 'Hold...');
        await Future.delayed(Duration(seconds: technique.holdAfterExhale));
      }

      setState(() => _breathCount++);
    }

    if (_isBreathing) {
      setState(() {
        _isBreathing = false;
        _breathingPhase = 'Complete! Great job 🎉';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Breathing Exercise'),
      ),
      body: Column(
        children: [
          // Technique Selector
          SizedBox(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.all(16),
              itemCount: _techniques.length,
              itemBuilder: (context, index) {
                final technique = _techniques[index];
                final isSelected = index == _selectedTechniqueIndex;

                return GestureDetector(
                  onTap: () {
                    if (!_isBreathing) {
                      setState(() => _selectedTechniqueIndex = index);
                    }
                  },
                  child: Container(
                    width: 180,
                    margin: const EdgeInsets.only(right: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: isSelected
                          ? const LinearGradient(
                              colors: [Color(0xFF667eea), Color(0xFF764ba2)],
                            )
                          : null,
                      color: isSelected ? null : theme.cardColor,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isSelected
                            ? Colors.transparent
                            : Colors.grey.shade300,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          technique.name,
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: isSelected ? Colors.white : null,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          technique.description,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: isSelected ? Colors.white70 : Colors.grey,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // Breathing Circle
          Expanded(
            child: Center(
              child: GestureDetector(
                onTap: _startBreathing,
                child: AnimatedBuilder(
                  animation: _scaleAnimation,
                  builder: (context, child) {
                    return Container(
                      width: 200 * _scaleAnimation.value,
                      height: 200 * _scaleAnimation.value,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            theme.colorScheme.primary.withOpacity(0.3),
                            theme.colorScheme.primary.withOpacity(0.6),
                            theme.colorScheme.primary,
                          ],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: theme.colorScheme.primary.withOpacity(0.3),
                            blurRadius: 40,
                            spreadRadius: 10,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          _breathingPhase,
                          style: theme.textTheme.titleLarge?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),

          // Stats
          Container(
            padding: const EdgeInsets.all(24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStat('Cycles', '$_breathCount'),
                _buildStat(
                  'Duration',
                  _isBreathing ? 'In progress...' : 'Not started',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStat(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey,
              ),
        ),
      ],
    );
  }
}

class BreathingTechnique {
  final String name;
  final String description;
  final int inhale;
  final int holdAfterInhale;
  final int exhale;
  final int holdAfterExhale;
  final int cycles;

  BreathingTechnique({
    required this.name,
    required this.description,
    required this.inhale,
    required this.holdAfterInhale,
    required this.exhale,
    required this.holdAfterExhale,
    required this.cycles,
  });
}