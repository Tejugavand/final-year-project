import 'package:flutter/material.dart';
import '../models/stress_result_model.dart';
import '../models/assessment_model.dart';
import '../services/stress_service.dart';
import '../core/constants/app_strings.dart';

class StressProvider extends ChangeNotifier {
  final StressService _stressService = StressService();
  List<AssessmentModel> _assessments = [];
  StressResultModel? _currentResult;
  List<StressResultModel> _history = [];
  bool _isLoading = false;
  String? _error;

  List<AssessmentModel> get assessments => _assessments;
  StressResultModel? get currentResult => _currentResult;
  List<StressResultModel> get history => _history;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAssessmentComplete =>
      _assessments.every((a) => a.selectedAnswer != null);

  void initializeAssessment() {
    _assessments = List.generate(
      AppStrings.questions.length,
      (index) => AssessmentModel(
        questionIndex: index,
        question: AppStrings.questions[index],
        options: AssessmentModel.standardOptions,
      ),
    );
    _currentResult = null;
    notifyListeners();
  }

  void answerQuestion(int questionIndex, int answer) {
    if (questionIndex >= 0 && questionIndex < _assessments.length) {
      _assessments[questionIndex] =
          _assessments[questionIndex].copyWith(selectedAnswer: answer);
      notifyListeners();
    }
  }

  Future<void> submitAssessment(String userId) async {
    if (!isAssessmentComplete) {
      _error = 'Please answer all questions';
      notifyListeners();
      return;
    }

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final answers = {
        for (var a in _assessments) a.questionIndex: a.selectedAnswer!
      };
      _currentResult =
          await _stressService.calculateStressResult(userId, answers);
      await loadHistory(userId);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      rethrow;
    }
  }

  Future<void> loadHistory(String userId) async {
    _isLoading = true;
    notifyListeners();

    try {
      _history = await _stressService.getStressHistory(userId);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}