class APIEndpoints {
  // Base URL - Replace with your backend URL
  static const String baseUrl = 'https://your-api.com/api';

  // Auth endpoints
  static const String login = '$baseUrl/auth/login';
  static const String register = '$baseUrl/auth/register';
  static const String logout = '$baseUrl/auth/logout';
  static const String refreshToken = '$baseUrl/auth/refresh';

  // User endpoints
  static const String getUser = '$baseUrl/users';
  static const String updateUser = '$baseUrl/users/update';

  // Stress assessment endpoints
  static const String submitAssessment = '$baseUrl/assessments/submit';
  static const String getHistory = '$baseUrl/assessments/history';
  static const String deleteAssessment = '$baseUrl/assessments/delete';
}