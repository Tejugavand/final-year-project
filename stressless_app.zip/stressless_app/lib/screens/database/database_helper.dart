import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../models/stress_result_model.dart';
import '../../models/user_model.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('stressless.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    const idType = 'TEXT PRIMARY KEY';
    const textType = 'TEXT NOT NULL';
    const intType = 'INTEGER NOT NULL';

    // Users table
    await db.execute('''
    CREATE TABLE users (
      id $idType,
      email $textType,
      full_name $textType,
      profile_image TEXT,
      created_at $textType,
      last_assessment_date TEXT,
      total_assessments $intType,
      current_stress_level TEXT
    )
    ''');

    // Stress results table
    await db.execute('''
    CREATE TABLE stress_results (
      id $idType,
      user_id $textType,
      score $intType,
      level $textType,
      answers $textType,
      completed_at $textType,
      recommendations TEXT
    )
    ''');
  }

  // User CRUD operations
  Future<void> insertUser(UserModel user) async {
    final db = await database;
    await db.insert(
      'users',
      user.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<UserModel?> getUser(String id) async {
    final db = await database;
    final maps = await db.query(
      'users',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return UserModel.fromJson(maps.first);
    }
    return null;
  }

  // Stress result CRUD operations
  Future<void> insertStressResult(StressResultModel result) async {
    final db = await database;
    await db.insert(
      'stress_results',
      result.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<StressResultModel>> getStressResults(String userId) async {
    final db = await database;
    final maps = await db.query(
      'stress_results',
      where: 'user_id = ?',
      whereArgs: [userId],
      orderBy: 'completed_at DESC',
    );

    return List.generate(maps.length, (i) {
      return StressResultModel.fromJson(maps[i]);
    });
  }

  Future<void> deleteStressResult(String id) async {
    final db = await database;
    await db.delete(
      'stress_results',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future close() async {
    final db = await database;
    db.close();
  }
}