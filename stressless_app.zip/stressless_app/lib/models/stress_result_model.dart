import 'package:equatable/equatable.dart';

/// StressResult model representing a completed stress assessment
class StressResultModel extends Equatable {
  final String id;
  final String userId;
  final int score;
  final String level; // 'low', 'moderate', 'high'
  final Map<int, int> answers; // question index -> answer value
  final DateTime completedAt;
  final List<String> recommendations;

  const StressResultModel({
    required this.id,
    required this.userId,
    required this.score,
    required this.level,
    required this.answers,
    required this.completedAt,
    required this.recommendations,
  });

  /// Calculate stress level from score
  static String calculateLevel(int score) {
    if (score <= 13) return 'low';
    if (score <= 26) return 'moderate';
    return 'high';
  }

  /// Get recommendations based on stress level
  static List<String> getRecommendations(String level) {
    switch (level.toLowerCase()) {
      case 'low':
        return [
          'Maintain your current healthy habits',
          'Continue regular exercise and sleep routine',
          'Practice mindfulness meditation daily',
        ];
      case 'moderate':
        return [
          'Take regular breaks during work',
          'Practice deep breathing exercises',
          'Consider talking to a friend or counselor',
          'Ensure 7-8 hours of quality sleep',
        ];
      case 'high':
        return [
          'Consult a mental health professional',
          'Reduce workload and commitments if possible',
          'Practice relaxation techniques daily',
          'Engage in physical activity regularly',
          'Avoid caffeine and alcohol',
        ];
      default:
        return [];
    }
  }

  factory StressResultModel.fromJson(Map<String, dynamic> json) {
    return StressResultModel(
      id: json['id'] as String,
      userId: json['user_id'] as String,
      score: json['score'] as int,
      level: json['level'] as String,
      answers: Map<int, int>.from(json['answers'] as Map),
      completedAt: DateTime.parse(json['completed_at'] as String),
      recommendations: List<String>.from(json['recommendations'] as List),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'score': score,
      'level': level,
      'answers': answers,
      'completed_at': completedAt.toIso8601String(),
      'recommendations': recommendations,
    };
  }

  @override
  List<Object?> get props => [id, userId, score, level, answers, completedAt];
}