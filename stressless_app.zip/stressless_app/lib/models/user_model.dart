import 'package:equatable/equatable.dart';

/// User model representing a registered user
class UserModel extends Equatable {
  final String id;
  final String email;
  final String fullName;
  final String? profileImage;
  final DateTime createdAt;
  final DateTime? lastAssessmentDate;
  final int totalAssessments;
  final String? currentStressLevel;

  const UserModel({
    required this.id,
    required this.email,
    required this.fullName,
    this.profileImage,
    required this.createdAt,
    this.lastAssessmentDate,
    this.totalAssessments = 0,
    this.currentStressLevel,
  });

  /// Create UserModel from JSON
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String,
      email: json['email'] as String,
      fullName: json['full_name'] as String,
      profileImage: json['profile_image'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
      lastAssessmentDate: json['last_assessment_date'] != null
          ? DateTime.parse(json['last_assessment_date'] as String)
          : null,
      totalAssessments: json['total_assessments'] as int? ?? 0,
      currentStressLevel: json['current_stress_level'] as String?,
    );
  }

  /// Convert UserModel to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'full_name': fullName,
      'profile_image': profileImage,
      'created_at': createdAt.toIso8601String(),
      'last_assessment_date': lastAssessmentDate?.toIso8601String(),
      'total_assessments': totalAssessments,
      'current_stress_level': currentStressLevel,
    };
  }

  /// Create a copy with updated fields
  UserModel copyWith({
    String? id,
    String? email,
    String? fullName,
    String? profileImage,
    DateTime? createdAt,
    DateTime? lastAssessmentDate,
    int? totalAssessments,
    String? currentStressLevel,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      fullName: fullName ?? this.fullName,
      profileImage: profileImage ?? this.profileImage,
      createdAt: createdAt ?? this.createdAt,
      lastAssessmentDate: lastAssessmentDate ?? this.lastAssessmentDate,
      totalAssessments: totalAssessments ?? this.totalAssessments,
      currentStressLevel: currentStressLevel ?? this.currentStressLevel,
    );
  }

  @override
  List<Object?> get props => [
        id,
        email,
        fullName,
        profileImage,
        createdAt,
        lastAssessmentDate,
        totalAssessments,
        currentStressLevel,
      ];

  @override
  String toString() {
    return 'UserModel(id: $id, email: $email, fullName: $fullName)';
  }
}