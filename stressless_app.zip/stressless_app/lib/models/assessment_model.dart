/// Assessment model for stress questionnaire
class AssessmentModel {
  final int questionIndex;
  final String question;
  final int? selectedAnswer;
  final List<String> options;

  const AssessmentModel({
    required this.questionIndex,
    required this.question,
    this.selectedAnswer,
    required this.options,
  });

  /// Standard PSS-10 response options
  static const List<String> standardOptions = [
    'Never',
    'Rarely',
    'Sometimes',
    'Often',
    'Very Often',
  ];

  /// Get response value (0-4) based on question type
  int getResponseValue(bool isReverseScored) {
    if (selectedAnswer == null) return 0;
    return isReverseScored ? (4 - selectedAnswer!) : selectedAnswer!;
  }

  AssessmentModel copyWith({int? selectedAnswer}) {
    return AssessmentModel(
      questionIndex: questionIndex,
      question: question,
      selectedAnswer: selectedAnswer ?? this.selectedAnswer,
      options: options,
    );
  }
}