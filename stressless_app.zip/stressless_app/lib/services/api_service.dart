import 'package:dio/dio.dart';
import '../core/constants/api_endpoints.dart';
import 'auth_service.dart';

class APIService {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: APIEndpoints.baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ),
  );

  final AuthService _authService = AuthService();

  APIService() {
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          // Add auth token to requests
          final token = await _authService.getToken();
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          return handler.next(options);
        },
        onError: (error, handler) async {
          // Handle token expiration
          if (error.response?.statusCode == 401) {
            // TODO: Refresh token logic
          }
          return handler.next(error);
        },
      ),
    );
  }

  // Auth endpoints
  Future<Response> login(String email, String password) async {
    return await _dio.post(
      APIEndpoints.login,
      data: {'email': email, 'password': password},
    );
  }

  Future<Response> register(
      String email, String password, String fullName) async {
    return await _dio.post(
      APIEndpoints.register,
      data: {'email': email, 'password': password, 'full_name': fullName},
    );
  }

  // Stress assessment endpoints
  Future<Response> submitAssessment(Map<String, dynamic> data) async {
    return await _dio.post(
      APIEndpoints.submitAssessment,
      data: data,
    );
  }

  Future<Response> getHistory(String userId) async {
    return await _dio.get('${APIEndpoints.getHistory}/$userId');
  }

  // Error handling
  String handleError(dynamic error) {
    if (error is DioException) {
      switch (error.type) {
        case DioExceptionType.connectionTimeout:
          return 'Connection timeout';
        case DioExceptionType.receiveTimeout:
          return 'Receive timeout';
        case DioExceptionType.badResponse:
          return error.response?.data['message'] ?? 'Server error';
        case DioExceptionType.cancel:
          return 'Request cancelled';
        default:
          return 'Network error';
      }
    }
    return error.toString();
  }
}