import '../models/stress_result_model.dart';
import 'dart:math';

class StressService {
  // Questions that use reverse scoring (positive questions)
  // PSS-10: Questions 4, 5, 7, 8 (0-indexed: 3, 4, 6, 7)
  static const List<int> reverseScoreQuestions = [3, 4, 6, 7];

  /// Calculate stress result from PSS-10 questionnaire
  Future<StressResultModel> calculateStressResult(
    String userId,
    Map<int, int> answers,
  ) async {
    // Simulate processing
    await Future.delayed(const Duration(milliseconds: 500));

    int totalScore = 0;

    // Calculate score with reverse scoring for positive questions
    for (var entry in answers.entries) {
      final questionIndex = entry.key;
      final answer = entry.value;

      if (reverseScoreQuestions.contains(questionIndex)) {
        // Reverse scoring: 0->4, 1->3, 2->2, 3->1, 4->0
        totalScore += (4 - answer);
      } else {
        totalScore += answer;
      }
    }

    final level = StressResultModel.calculateLevel(totalScore);
    final recommendations = StressResultModel.getRecommendations(level);

    return StressResultModel(
      id: 'result_${DateTime.now().millisecondsSinceEpoch}',
      userId: userId,
      score: totalScore,
      level: level,
      answers: answers,
      completedAt: DateTime.now(),
      recommendations: recommendations,
    );
  }

  /// Get stress history - Replace with database query
  Future<List<StressResultModel>> getStressHistory(String userId) async {
    await Future.delayed(const Duration(milliseconds: 300));

    // Mock history - replace with actual database query
    final random = Random();
    return [
      StressResultModel(
        id: 'result_1',
        userId: userId,
        score: 18 + random.nextInt(5),
        level: 'moderate',
        answers: {},
        completedAt: DateTime.now().subtract(const Duration(days: 7)),
        recommendations: StressResultModel.getRecommendations('moderate'),
      ),
      StressResultModel(
        id: 'result_2',
        userId: userId,
        score: 10 + random.nextInt(5),
        level: 'low',
        answers: {},
        completedAt: DateTime.now().subtract(const Duration(days: 14)),
        recommendations: StressResultModel.getRecommendations('low'),
      ),
      StressResultModel(
        id: 'result_3',
        userId: userId,
        score: 22 + random.nextInt(5),
        level: 'moderate',
        answers: {},
        completedAt: DateTime.now().subtract(const Duration(days: 21)),
        recommendations: StressResultModel.getRecommendations('moderate'),
      ),
    ];
  }

  /// Save assessment to database - Implement with SQLite
  Future<void> saveAssessment(StressResultModel result) async {
    // TODO: Implement with SQLite
    await Future.delayed(const Duration(milliseconds: 200));
  }

  /// Delete assessment - Implement with SQLite
  Future<void> deleteAssessment(String id) async {
    // TODO: Implement with SQLite
    await Future.delayed(const Duration(milliseconds: 200));
  }
}